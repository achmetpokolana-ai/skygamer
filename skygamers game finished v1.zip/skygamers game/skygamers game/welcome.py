import os

def main():
    while True:
        print("Willkommen! Bitte wähle eine Option:")
        print("1. Einloggen")
        print("2. Registrieren")
        print("3. Beenden")

        auswahl = input("Deine Wahl: ").strip()

        if auswahl == "1":
            # login.py ausführen
            os.system("python login.py")
        elif auswahl == "2":
            # register.py ausführen
            os.system("python register.py")
        elif auswahl == "3":
            print("Programm wird beendet.")
            break
        else:
            print("Ungültige Eingabe. Bitte wähle 1, 2 oder 3.")

if __name__ == "__main__":
    main()
