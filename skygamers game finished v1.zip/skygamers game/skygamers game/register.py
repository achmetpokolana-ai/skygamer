import re
from pathlib import Path
import dns.resolver
import dns.exception
import subprocess
import sys

FILENAME = "contacts.txt"
HEADER = "--- CONTACT LIST ---"
MIN_NAME_LEN = 1
MAX_NAME_LEN = 100
DNS_TIMEOUT = 5  # Sekunden für DNS-Anfragen


def valid_name(name: str) -> bool:
    """Nur alphabetische Zeichen, evtl. Leerzeichen erlauben."""
    name = name.strip()
    if not (MIN_NAME_LEN <= len(name) <= MAX_NAME_LEN):
        return False
    # Erlaube alles außer Ziffern und die häufigsten Sonderzeichen
    return bool(re.fullmatch(r"[^\d!@#$%^&*()_+={}\[\]|\\;:\"<>,.?/~]+", name))


def valid_email_format(email: str) -> bool:
    """Einfache Syntaxprüfung der E-Mail-Adresse (keine vollständige RFC-Implementierung)."""
    email = email.strip()
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email))


def email_domain_exists(email: str) -> bool:
    """
    Prüft, ob die Domain der E-Mail existiert und E-Mails empfangen könnte.
    Vorgehen:
    1. MX-Records prüfen
    2. Fallback: A / AAAA Records prüfen
    """
    try:
        if "@" not in email:
            return False

        domain = email.split("@", 1)[1].strip().lower()
        if not domain:
            return False

        try:
            domain_idna = domain.encode("idna").decode("ascii")
        except Exception:
            domain_idna = domain

        # MX-Check
        try:
            answers = dns.resolver.resolve(domain_idna, "MX", lifetime=DNS_TIMEOUT)
            if answers.rrset and len(answers) > 0:
                return True
        except dns.resolver.NoAnswer:
            pass
        except dns.resolver.NXDOMAIN:
            return False
        except dns.exception.DNSException:
            pass

        # A-Check
        try:
            answers_a = dns.resolver.resolve(domain_idna, "A", lifetime=DNS_TIMEOUT)
            if answers_a.rrset and len(answers_a) > 0:
                return True
        except dns.resolver.NoAnswer:
            pass
        except dns.resolver.NXDOMAIN:
            return False
        except dns.exception.DNSException:
            pass

        # AAAA-Check
        try:
            answers_aaaa = dns.resolver.resolve(domain_idna, "AAAA", lifetime=DNS_TIMEOUT)
            if answers_aaaa.rrset and len(answers_aaaa) > 0:
                return True
        except dns.resolver.NoAnswer:
            pass
        except dns.resolver.NXDOMAIN:
            return False
        except dns.exception.DNSException:
            pass

        return False
    except Exception:
        return False


def valid_email(email: str) -> bool:
    """E-Mail validieren: Format + Domainprüfung."""
    email = email.strip()
    if not valid_email_format(email):
        return False
    return email_domain_exists(email)


def parse_contacts_from_text(text: str):
    """Alle vorhandenen username/email Paare extrahieren."""
    pattern = re.compile(
        r"username:\s*([^;\n\r]+?)\s+email:\s*([^;\s\n\r]+)",
        re.IGNORECASE,
    )

    contacts = pattern.findall(text)

    normalized = []
    seen_emails = set()
    seen_usernames = set()

    for name, email in contacts:
        name = " ".join(name.split())
        email = email.strip()

        if email.lower() in seen_emails or name.lower() in seen_usernames:
            continue

        seen_emails.add(email.lower())
        seen_usernames.add(name.lower())
        normalized.append((name, email))

    return normalized


def repair_contacts_file(filename: str = FILENAME):
    """Datei reparieren, normalisieren und Header einfügen."""
    path = Path(filename)

    if not path.exists():
        path.write_text(HEADER + "\n", encoding="utf-8")
        return []

    text = path.read_text(encoding="utf-8")
    contacts = parse_contacts_from_text(text)

    lines = [HEADER]
    seen_emails = set()
    seen_usernames = set()

    for name, email in contacts:
        if email.lower() in seen_emails or name.lower() in seen_usernames:
            continue

        seen_emails.add(email.lower())
        seen_usernames.add(name.lower())
        lines.append(f"username: {name} email: {email}")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return contacts


def load_existing(filename: str = FILENAME):
    """Lade vorhandene Usernames und E-Mails."""
    usernames = set()
    emails = set()

    path = Path(filename)
    if not path.exists():
        return usernames, emails

    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.search(r"username:\s*(.*?)\s+email:\s*(\S+)", line, re.IGNORECASE)
        if m:
            usernames.add(m.group(1).strip().lower())
            emails.add(m.group(2).strip().lower())

    return usernames, emails


def append_contact_line(name: str, email: str, filename: str = FILENAME):
    """Neue Zeile ans Ende der Datei anhängen."""
    path = Path(filename)
    line = f"username: {name} email: {email}"

    with path.open("a+", encoding="utf-8") as f:
        f.seek(0, 2)
        if f.tell() != 0:
            f.write("\n")
        f.write(line)


def main():
    repair_contacts_file(FILENAME)

    while True:
        existing_usernames, existing_emails = load_existing(FILENAME)

        name = input("Benutzername (nicht dein echter Name): ").strip()
        email = input("E-Mail-Adresse: ").strip()

        if not valid_name(name):
            print("Ungültiger Name.")
            continue

        if not valid_email_format(email):
            print("Ungültiges E-Mail-Format.")
            continue

        # DNS/Domain-Check optional lange Wartezeit; du kannst ihn entfernen, wenn du Offline arbeitest
        if not email_domain_exists(email):
            print("E-Mail-Domain nicht erreichbar oder nicht korrekt konfiguriert.")
            continue

        if name.lower() in existing_usernames:
            print("Benutzername existiert bereits.")
            continue

        if email.lower() in existing_emails:
            print("E-Mail existiert bereits.")
            continue

        try:
            append_contact_line(name, email)
            print(f"username: {name} email: {email}")

            # --- Neues: Spiel starten ---
            try:
                # Nutzt dieselbe Python-Executable wie dieses Script (wichtig bei venv)
                subprocess.run([sys.executable, "game.py", name])
            except Exception as e:
                print("Fehler beim Starten von game.py:", e)

            break  # Registrierung erfolgreich, Schleife beenden
        except Exception as e:
            print("Fehler beim Speichern:", e)
            break


if __name__ == "__main__":
    main()

