import re
import subprocess
import sys
from pathlib import Path

FILENAME = "contacts.txt"

def load_users(filename: str = FILENAME) -> dict:
    """Lädt username → email Paare aus der contacts.txt."""
    users = {}
    path = Path(filename)

    if not path.exists():
        return users

    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.search(r"username:\s*(.*?)\s+email:\s*(\S+)", line, re.IGNORECASE)
        if m:
            uname = m.group(1).strip().lower()
            mail = m.group(2).strip().lower()
            users[uname] = mail

    return users

def login() -> str | None:
    """Fragt Benutzername und E-Mail ab und prüft Login.
       Gibt den Benutzernamen zurück, wenn Login erfolgreich, sonst None."""
    users = load_users()
    if not users:
        print("❌ Es sind keine Benutzer registriert.")
        return None

    uname = input("Benutzername: ").strip().lower()
    mail = input("E-Mail: ").strip().lower()

    if uname in users and users[uname] == mail:
        print("✅ Login erfolgreich!")
        return uname

    print("❌ Ungültiger Benutzername oder E-Mail.")
    return None

if __name__ == "__main__":
    username = login()
    if username:
        try:
            # game.py starten mit username als Argument
            subprocess.run([sys.executable, "game.py", username])
        except Exception as e:
            print("Fehler beim Starten von game.py:", e)

