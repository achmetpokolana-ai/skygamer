import pygame
import random
import sys
import os

# ==================================================
#  ENDLESS RUNNER – mit Unicode-Highscoreanzeige (gefixt)
# ==================================================

# --- Prüfen, ob Username übergeben wurde ---
if len(sys.argv) <= 1:
    os.system("python welcome.py")
    sys.exit()
username = sys.argv[1].strip()

pygame.init()
pygame.font.init()

# --- Bildschirm ---
BASE_WIDTH, BASE_HEIGHT = 800, 400
screen = pygame.display.set_mode((BASE_WIDTH, BASE_HEIGHT))
pygame.display.set_caption("Endless Runner")
clock = pygame.time.Clock()
WIDTH, HEIGHT = screen.get_size()

# --- Fonts (Systemfont) ---
font = pygame.font.SysFont("Arial", 36)
big_font = pygame.font.SysFont("Arial", 72)

# --- Farben ---
WHITE = (255, 255, 255)
BLUE_SKY = (135, 206, 235)
GREEN = (0, 200, 0)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
HIGHLIGHT = (255, 230, 150)

# --- Spieler ---
PLAYER_SIZE = 50
player_x = 100
player_y = 0
player_vel_y = 0.0
gravity = 0.5
jump_strength = -10
on_ground = False
extra_jump_available = False

# --- Plattformen ---
PLATFORM_HEIGHT = 20
platforms = []
SCROLL_BASE_SPEED = 5
MIN_PLATFORM_WIDTH = 80
MAX_PLATFORM_WIDTH = 150
MAX_HEIGHT_DIFF = 80

# --- Wolken (Powerups) ---
CLOUD_WIDTH, CLOUD_HEIGHT = 80, 50
CLOUD_SPEED = 2
clouds = []
cloud_spawn_timer = 0
next_cloud_spawn = random.randint(8000, 12000)

# --- Temporäre Safety Plattform ---
safety_platform = None
safety_end_time = 0
SAFETY_DURATION_MS = 3000

# --- Fullscreen entprellung ---
last_fullscreen_toggle = 0
FULLSCREEN_DEBOUNCE_MS = 300

# --- Score / Highscore ---
score = 0
highscore_file = "highscore.txt"
highscores = {}
highscore = 0

# --- Highscore Overlay ---
show_highscores = False
hs_scroll = 0
HS_DISPLAY_COUNT = 10

# --- Spielzustand ---
paused = False
game_over = False
running = True

# --- Game over helper (to avoid saving each frame) ---
game_over_surfaces = None
_saved_on_game_over = False

# -------------------------
# Highscore Funktionen
# -------------------------
def load_highscores(path: str):
    d = {}
    if not os.path.exists(path):
        return d
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if ":" in line:
                    u, s = line.strip().split(":", 1)
                    try:
                        d[u.strip()] = int(s.strip())
                    except:
                        d[u.strip()] = 0
    except Exception:
        pass
    return d

def save_highscores(path: str, d: dict):
    try:
        with open(path, "w", encoding="utf-8") as f:
            for u, s in d.items():
                f.write(f"{u}:{s}\n")
    except Exception as e:
        print("Fehler beim Speichern der Highscores:", e)

def save_current_if_better():
    global highscores, username, highscore, score
    prev = highscores.get(username, 0)
    if score > prev:
        highscores[username] = score
        highscore = score
        save_highscores(highscore_file, highscores)

def get_sorted_highscore_list(path: str):
    d = load_highscores(path)
    items = list(d.items())
    items.sort(key=lambda x: (-x[1], x[0].lower()))
    return items

# lade highscores beim Start
highscores = load_highscores(highscore_file)
highscore = highscores.get(username, 0)

# -------------------------
# Hilfsfunktionen / Game
# -------------------------
def add_temporary_safety_platform(at_start=False):
    global safety_platform, safety_end_time, platforms
    w = 300
    y = HEIGHT - 120
    x = player_x - 50 if not at_start else 0
    temp_plat = pygame.Rect(x, y, w, PLATFORM_HEIGHT)
    platforms.insert(1 if platforms else 0, temp_plat)
    safety_platform = temp_plat
    safety_end_time = pygame.time.get_ticks() + SAFETY_DURATION_MS

def toggle_fullscreen():
    global screen, WIDTH, HEIGHT, last_fullscreen_toggle
    now = pygame.time.get_ticks()
    if now - last_fullscreen_toggle < FULLSCREEN_DEBOUNCE_MS:
        return
    last_fullscreen_toggle = now
    if screen.get_flags() & pygame.FULLSCREEN:
        screen = pygame.display.set_mode((BASE_WIDTH, BASE_HEIGHT))
    else:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    WIDTH, HEIGHT = screen.get_size()
    add_temporary_safety_platform()

def reset_game():
    global player_y, player_vel_y, on_ground
    global platforms, clouds, score, game_over, safety_platform, safety_end_time, extra_jump_available
    global game_over_surfaces, _saved_on_game_over
    platforms.clear()
    start_plat = pygame.Rect(0, HEIGHT - PLATFORM_HEIGHT, 200, PLATFORM_HEIGHT)
    platforms.append(start_plat)
    x_pos = start_plat.right
    prev_y = start_plat.top
    while x_pos < WIDTH * 2:
        w = random.randint(MIN_PLATFORM_WIDTH, MAX_PLATFORM_WIDTH)
        min_y = max(HEIGHT - 200, prev_y - MAX_HEIGHT_DIFF)
        max_y = min(HEIGHT - 80, prev_y + MAX_HEIGHT_DIFF)
        if min_y > max_y:
            min_y, max_y = max_y, min_y
        y = random.randint(min_y, max_y)
        platforms.append(pygame.Rect(x_pos, y, w, PLATFORM_HEIGHT))
        prev_y = y
        x_pos += w

    player_y = platforms[0].top - PLAYER_SIZE
    player_vel_y = 0
    on_ground = True
    extra_jump_available = False
    clouds.clear()
    score = 0
    game_over = False
    safety_platform = None
    safety_end_time = 0
    # reset game-over helpers
    game_over_surfaces = None
    _saved_on_game_over = False

class Cloud:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, CLOUD_WIDTH, CLOUD_HEIGHT)
    def update(self):
        self.rect.x -= CLOUD_SPEED

def prepare_game_over_surfaces():
    """Pre-render Game Over texts once (avoid per-frame rendering)."""
    global game_over_surfaces, score, highscore
    game_over_surfaces = {}
    game_over_surfaces['title'] = big_font.render("GAME OVER", True, BLACK)
    game_over_surfaces['points'] = font.render(f"Punkte: {score}", True, BLACK)
    game_over_surfaces['high'] = font.render(f"Highscore (dein): {highscore}", True, BLACK)
    game_over_surfaces['close'] = font.render("Spiel schließen: Q oder 1", True, BLACK)
    game_over_surfaces['restart'] = font.render("Restart: R", True, BLACK)
    game_over_surfaces['leader'] = font.render("Leaderboard: H", True, BLACK)

def draw_highscore_overlay():
    global hs_scroll
    hs_list = get_sorted_highscore_list(highscore_file)
    total = len(hs_list)
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(220)
    overlay.fill((240, 240, 240))
    screen.blit(overlay, (0, 0))
    title_surf = big_font.render("Highscores", True, BLACK)
    screen.blit(title_surf, ((WIDTH - title_surf.get_width()) // 2, 20))

    if total == 0:
        txt = font.render("Keine Highscores vorhanden.", True, BLACK)
        screen.blit(txt, ((WIDTH - txt.get_width()) // 2, HEIGHT // 2))
        return

    max_scroll = max(0, total - HS_DISPLAY_COUNT)
    hs_scroll = max(0, min(hs_scroll, max_scroll))
    start = hs_scroll
    end = min(total, start + HS_DISPLAY_COUNT)
    y = 120
    line_h = 36
    rank = start + 1
    for i in range(start, end):
        u, s = hs_list[i]
        icon = "★" if u == username else ""
        txt_surf = font.render(f"{icon} {rank}. {u} – {s}", True, BLACK)
        if u == username:
            rect = pygame.Rect(80, y - 6, WIDTH - 160, line_h)
            pygame.draw.rect(screen, HIGHLIGHT, rect)
        screen.blit(txt_surf, (100, y))
        y += line_h + 6
        rank += 1

    arrow_color = BLACK
    if hs_scroll > 0:
        pygame.draw.polygon(screen, arrow_color, [(WIDTH - 40, 120), (WIDTH - 20, 120), (WIDTH - 30, 100)])
    if hs_scroll + HS_DISPLAY_COUNT < total:
        pygame.draw.polygon(screen, arrow_color, [(WIDTH - 40, HEIGHT - 80), (WIDTH - 20, HEIGHT - 80), (WIDTH - 30, HEIGHT - 60)])

    hint = font.render("H: schließen   ↑/↓: scrollen", True, BLACK)
    screen.blit(hint, ((WIDTH - hint.get_width()) // 2, HEIGHT - 50))

# initialisieren
reset_game()

# -------------------------
# Hauptschleife
# -------------------------
while running:
    dt = clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # safe write once before exit
            save_current_if_better()
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_h:
                show_highscores = not show_highscores
                if show_highscores:
                    hs_scroll = 0
            if show_highscores:
                if event.key == pygame.K_UP:
                    hs_scroll -= 1
                if event.key == pygame.K_DOWN:
                    hs_scroll += 1
            else:
                if event.key == pygame.K_F11 or event.key == pygame.K_f:
                    toggle_fullscreen()
                if event.key == pygame.K_1 or event.key == pygame.K_q:
                    save_current_if_better()
                    running = False
                if event.key == pygame.K_ESCAPE:
                    if not game_over:
                        paused = not paused
                if event.key == pygame.K_r:
                    reset_game()

    # Highscore Overlay: Spiel pausiert
    if show_highscores:
        screen.fill(BLUE_SKY)
        draw_highscore_overlay()
        pygame.display.flip()
        continue

    if paused:
        screen.fill(WHITE)
        screen.blit(big_font.render("PAUSE", True, BLACK), ((WIDTH - 200)//2, HEIGHT//2))
        pygame.display.flip()
        continue

    # --- Spiel-Update ---
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] and on_ground:
        player_vel_y = jump_strength
        on_ground = False
    if keys[pygame.K_SPACE] and not on_ground and extra_jump_available:
        player_vel_y = jump_strength
        extra_jump_available = False

    cloud_spawn_timer += dt
    if cloud_spawn_timer >= next_cloud_spawn:
        cloud_spawn_timer = 0
        next_cloud_spawn = random.randint(8000, 12000)
        spawn_y = random.randint(max(0, HEIGHT - PLATFORM_HEIGHT - 200), max(0, HEIGHT - PLATFORM_HEIGHT - 120))
        clouds.append(Cloud(WIDTH, spawn_y))

    prev_y = player_y
    player_vel_y += gravity
    player_y += player_vel_y

    player_rect = pygame.Rect(player_x, player_y, PLAYER_SIZE, PLAYER_SIZE)
    on_ground = False
    for plat in platforms:
        if (
            player_rect.bottom >= plat.top - 6
            and prev_y + PLAYER_SIZE <= plat.top + 6
            and player_rect.right > plat.left
            and player_rect.left < plat.right
        ):
            player_y = plat.top - PLAYER_SIZE
            player_vel_y = 0
            on_ground = True
            break

    for cloud in clouds[:]:
        if player_rect.colliderect(cloud.rect):
            extra_jump_available = True
            clouds.remove(cloud)

    if safety_platform and pygame.time.get_ticks() >= safety_end_time:
        try: platforms.remove(safety_platform)
        except ValueError: pass
        safety_platform = None

    # When player falls -> set game_over once and prepare surfaces + save once
    if player_y > HEIGHT and not game_over:
        game_over = True
        # update highscores dict from file to include external changes and then save if needed
        highscores = load_highscores(highscore_file)
        # update global highscore for this session display
        prev_local = highscores.get(username, 0)
        if score > prev_local:
            highscores[username] = score
            highscore = score
            save_highscores(highscore_file, highscores)
        else:
            highscore = highscores.get(username, 0)
        # prepare the surfaces for the static Game Over screen
        prepare_game_over_surfaces()
        _saved_on_game_over = True

    # If now game_over, show static Game Over screen (no heavy ops)
    if game_over:
        # draw pre-rendered surfaces (fast)
        screen.fill(WHITE)
        # center title
        title = game_over_surfaces['title']
        screen.blit(title, ((WIDTH - title.get_width()) // 2, HEIGHT//2 - 120))
        # points
        p = game_over_surfaces['points']
        screen.blit(p, ((WIDTH - p.get_width()) // 2, HEIGHT//2 - 40))
        # highscore
        h = game_over_surfaces['high']
        screen.blit(h, ((WIDTH - h.get_width()) // 2, HEIGHT//2 + 5))
        # controls
        screen.blit(game_over_surfaces['close'], ((WIDTH - game_over_surfaces['close'].get_width()) // 2, HEIGHT//2 + 55))
        screen.blit(game_over_surfaces['restart'], ((WIDTH - game_over_surfaces['restart'].get_width()) // 2, HEIGHT//2 + 95))
        screen.blit(game_over_surfaces['leader'], ((WIDTH - game_over_surfaces['leader'].get_width()) // 2, HEIGHT//2 + 135))
        pygame.display.flip()
        continue

    # continue normal platform movement and generation
    speed = SCROLL_BASE_SPEED + (score // 100) * 0.1
    for plat in platforms:
        plat.x -= speed
    platforms = [p for p in platforms if p.right > 0]

    while platforms[-1].right < WIDTH * 2:
        w = random.randint(MIN_PLATFORM_WIDTH, MAX_PLATFORM_WIDTH)
        prev_y = platforms[-1].top
        min_y = max(HEIGHT - 200, prev_y - MAX_HEIGHT_DIFF)
        max_y = min(HEIGHT - 80, prev_y + MAX_HEIGHT_DIFF)
        if min_y > max_y: min_y, max_y = max_y, min_y
        y = random.randint(min_y, max_y)
        x = platforms[-1].right
        platforms.append(pygame.Rect(x, y, w, PLATFORM_HEIGHT))

    for cloud in clouds:
        cloud.update()
    clouds = [c for c in clouds if c.rect.right > 0]

    score += 1
    if score > highscore:
        highscore = score

    # --- Zeichnen ---
    screen.fill(BLUE_SKY)
    pygame.draw.rect(screen, RED, (player_x, player_y, PLAYER_SIZE, PLAYER_SIZE))
    for plat in platforms:
        pygame.draw.rect(screen, GREEN, plat)
    for cloud in clouds:
        pygame.draw.ellipse(screen, WHITE, cloud.rect)

    screen.blit(font.render(f"Punkte: {score}", True, BLACK), (10, 10))
    screen.blit(font.render(f"Highscore: {highscore}", True, BLACK), (10, 50))
    screen.blit(font.render(username, True, BLACK), (WIDTH - 160, 10))

    pygame.display.flip()

# Ende Hauptschleife
save_current_if_better()
pygame.quit()
sys.exit()